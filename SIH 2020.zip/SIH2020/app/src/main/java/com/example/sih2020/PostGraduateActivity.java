package com.example.sih2020;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PostGraduateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_graduate);
    }
}