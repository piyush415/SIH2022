package com.example.sih2020;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ImageView postGView = findViewById(R.id.pgIV);
        ImageView underGView = findViewById(R.id.ugIV);
        ImageView moocView = findViewById(R.id.moocIV);
        ImageView phdView = findViewById(R.id.phdIV);
        postGView.setOnClickListener(v -> {

            startActivity(new Intent(MainActivity.this,PostGraduateActivity.class));

        });

        underGView.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,UnderGraduateActivity.class));


        });

        moocView.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,MoocActivity.class));


        });

        phdView.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,phdActivity.class));


        });

    }
}